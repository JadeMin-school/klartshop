export interface Address {
	id: string;
	street: string;
	detail: string;
}